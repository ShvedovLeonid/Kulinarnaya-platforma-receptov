import os
import datetime
from flask import Flask, render_template, redirect, abort, flash, url_for, request, jsonify
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from werkzeug.utils import secure_filename
from data import db_session
from data.users import User
from data.recipes import Recipe
from forms.user import RegisterForm, LoginForm
from forms.recipe import RecipeForm

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
app.config['UPLOAD_FOLDER'] = 'static/uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

# Создаём папку для загрузок, если её нет
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def save_picture(file):
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        new_filename = f"{current_user.id}_{int(datetime.datetime.now().timestamp())}_{filename}"
        file.save(os.path.join(app.config['UPLOAD_FOLDER'], new_filename))
        return new_filename
    return None


@login_manager.user_loader
def load_user(user_id):
    db_sess = db_session.create_session()
    return db_sess.get(User, user_id)


@app.route('/')
@app.route('/index')
def main_page():
    db_sess = db_session.create_session()
    recipes = db_sess.query(Recipe).all()
    return render_template('index.html', title='Главная - Кулинарная платформа', recipes=recipes)


@app.route('/recipe/<int:id>')
def recipe_detail(id):
    db_sess = db_session.create_session()
    recipe = db_sess.query(Recipe).filter(Recipe.id == id).first()
    if not recipe:
        abort(404)
    return render_template('recipe_detail.html', title=recipe.title, recipe=recipe)


@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Пароли не совпадают")
        db_sess = db_session.create_session()
        if db_sess.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Такой пользователь уже есть")
        user = User(
            surname=form.surname.data,
            name=form.name.data,
            age=form.age.data,
            position=form.position.data,
            speciality=form.speciality.data,
            address=form.address.data,
            email=form.email.data
        )
        user.set_password(form.password.data)
        db_sess.add(user)
        db_sess.commit()
        return redirect('/login')
    return render_template('register.html', title='Регистрация', form=form)


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        user = db_sess.query(User).filter(User.email == form.email.data).first()
        if user and user.check_password(form.password.data):
            login_user(user, remember=form.remember_me.data)
            return redirect("/")
        return render_template('login.html',
                               message="Неправильный логин или пароль",
                               form=form)
    return render_template('login.html', title='Авторизация', form=form)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect("/")


@app.route('/add_recipe', methods=['GET', 'POST'])
@login_required
def add_recipe():
    form = RecipeForm()
    if form.validate_on_submit():
        img_file = save_picture(form.image.data)
        db_sess = db_session.create_session()
        recipe = Recipe(
            title=form.title.data,
            description=form.description.data,
            ingredients=form.ingredients.data,
            cooking_time=form.cooking_time.data,
            image_filename=img_file,
            user_id=current_user.id
        )
        db_sess.add(recipe)
        db_sess.commit()
        flash('Рецепт успешно добавлен!', 'success')
        return redirect("/")
    return render_template('add_recipe.html', title='Добавление рецепта', form=form)


@app.route('/edit_recipe/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_recipe(id):
    form = RecipeForm()
    db_sess = db_session.create_session()
    recipe = db_sess.query(Recipe).filter(Recipe.id == id).first()

    if not recipe:
        abort(404)

    if recipe.user_id != current_user.id:
        abort(403)

    if request.method == 'GET':
        form.title.data = recipe.title
        form.description.data = recipe.description
        form.ingredients.data = recipe.ingredients
        form.cooking_time.data = recipe.cooking_time

    if form.validate_on_submit():
        recipe.title = form.title.data
        recipe.description = form.description.data
        recipe.ingredients = form.ingredients.data
        recipe.cooking_time = form.cooking_time.data

        if form.image.data:
            img_file = save_picture(form.image.data)
            if img_file:
                recipe.image_filename = img_file

        db_sess.commit()
        flash('Рецепт успешно изменён!', 'success')
        return redirect(f'/recipe/{id}')

    return render_template('edit_recipe.html', title='Редактирование рецепта', form=form, recipe=recipe)


@app.route('/delete_recipe/<int:id>', methods=['POST'])
@login_required
def delete_recipe(id):
    db_sess = db_session.create_session()
    recipe = db_sess.query(Recipe).filter(Recipe.id == id).first()

    if not recipe:
        abort(404)

    if recipe.user_id != current_user.id:
        abort(403)

    db_sess.delete(recipe)
    db_sess.commit()
    flash('Рецепт успешно удалён!', 'success')
    return redirect("/")


@app.route('/personal')
@login_required
def personal_page():
    db_sess = db_session.create_session()
    my_recipes = db_sess.query(Recipe).filter(Recipe.user_id == current_user.id).all()
    return render_template('personal.html', title='Мои рецепты', recipes=my_recipes)


# REST API
@app.route('/api/recipes')
def api_recipes():
    db_sess = db_session.create_session()
    recipes = db_sess.query(Recipe).all()
    return jsonify([{
        'id': r.id,
        'title': r.title,
        'cooking_time': r.cooking_time,
        'created_date': r.created_date.isoformat(),
        'author': f"{r.user.name} {r.user.surname}" if r.user else "Unknown",
        'image_url': f'/static/uploads/{r.image_filename}' if r.image_filename else None
    } for r in recipes])


@app.route('/api/recipe/<int:id>')
def api_recipe(id):
    db_sess = db_session.create_session()
    recipe = db_sess.query(Recipe).get(id)
    if not recipe:
        return jsonify({'error': 'Recipe not found'}), 404
    return jsonify({
        'id': recipe.id,
        'title': recipe.title,
        'description': recipe.description,
        'ingredients': recipe.ingredients,
        'cooking_time': recipe.cooking_time,
        'created_date': recipe.created_date.isoformat(),
        'author': f"{recipe.user.name} {recipe.user.surname}" if recipe.user else "Unknown"
    })


def main():
    db_session.global_init("db/recipes.db")
    app.run(debug=True)


if __name__ == '__main__':
    main()