from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, IntegerField, SubmitField
from wtforms.validators import DataRequired
from flask_wtf.file import FileField, FileAllowed


class RecipeForm(FlaskForm):
    title = StringField('Название блюда', validators=[DataRequired()])
    description = TextAreaField('Описание приготовления', validators=[DataRequired()])
    ingredients = TextAreaField('Ингредиенты (каждый с новой строки)', validators=[DataRequired()])
    cooking_time = IntegerField('Время приготовления (минуты)', validators=[DataRequired()])
    image = FileField('Фото блюда', validators=[FileAllowed(['jpg', 'png', 'jpeg', 'gif'], 'Только изображения!')])
    submit = SubmitField('Опубликовать рецепт')